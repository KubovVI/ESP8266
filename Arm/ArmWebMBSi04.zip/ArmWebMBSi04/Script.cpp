#include "Script.h"

int scrPoint=0;
boolean scrRun=false;
long oldMillis;

int scrLength=9;
int16_t scrServos[_scrSize][_servoNum]={
    {285,380,450,120,310,300},
    {285,140,300,200,310,270},
    {285,140,300,200,310,390},
    {285,380,450,120,310,390},
    { 90,380,450,120,310,390},
    { 90,140,300,180,310,390},
    { 90,140,300,180,310,270},
    { 90,380,450,120,310,270},
    {285,380,450,120,310,270},    
  };

boolean scriptProcessing(boolean cycle){
  if (!scrRun){ scrRun=true; if (cycle) scrPoint=0; }
  if (scrPoint>=scrLength){ scrRun=false; return false; }
  if (!servosReady()) return false;
  if ((millis()-oldMillis)<_scrMillis) return false;
  for (int i=0; i<_servoNum; i++) HoldReg[i+1]=scrServos[scrPoint][i]; 
  oldMillis=millis();
  scrPoint++; 
  return true; 
}//scriptProcessing

void scriptSet0(){ scrPoint=0;}
