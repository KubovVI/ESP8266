extern int16_t HoldReg[];
//#include <ESP8266WebServer.h>
extern ESP8266WebServer server;

extern boolean webData;

String servoMob(){
  String form="<html>\n<head>\n\
  <meta name='viewport' content='width=device-width, initial-scale=0.5'>\n\
  <style>\n\
  body,table,button,input {font-size:30px; height:40px; text-align:center} \n\
  input[type=text]{width:80px; text-align:right}\n\ 
  input[type=range]{width:100%; height:50px}\n\
  input[type=checkbox]{width:30px; height:30px}\n\ 
  </style>\n\
<script>\n\
var sData='';\n\
function init(){\n\
  for (r=0;r<6;r++){\n\
    var cR=TB.rows[r+1].cells[1].children[0];\n\
    var cT=TB.rows[r+1].cells[2].children[0];\n\
    cR.min=80; cR.max=520;\n\
  }//for\n\ 
  getData(false);\n\
}//init\n\
function rChange(r){\n\
  var cR=TB.rows[r+1].cells[1].children[0];\n\
  var cT=TB.rows[r+1].cells[2].children[0];\n\
  cT.value=cR.value;\n\
  if (CB.checked) getData(true);\n\
}//rChange\n\
function tChange(r){\n\
  var cR=TB.rows[r+1].cells[1].children[0];\n\
  var cT=TB.rows[r+1].cells[2].children[0];\n\
  cR.value=cT.value;\n\
}//tChange\n\
function packData(){\n\
  sData='';\n\
  for (r=0; r<6; r++){\n\
    var cT=TB.rows[r+1].cells[2].children[0];\n\
      sData+=parseInt(cT.value)+' ';\n\ 
  }//for r\n\
}//packData\n\
function unpackData(){\n\
  var adata=sData.split(' ');\n\
  i=0;\n\
  for (r=0; r<6; r++){\n\
    var cT=TB.rows[r+1].cells[2].children[0];\n\
    var cR=TB.rows[r+1].cells[1].children[0];\n\
    cT.value=adata[r]; cR.value=cT.value;\n\
    i++;\n\
  }//for r\n\
}//unpackData\n\
function getData(send){\n\
  if (send)packData(); else sData='';\n\
  var xhttp=new XMLHttpRequest();\n\
  xhttp.open('GET','?data='+sData,true);\n\
  xhttp.send();\n\
  xhttp.onload=function(){\n\
    sData=this.responseText.trim();\n\
    unpackData();\n\   
  }//onload\n\
}//getData\n\    
</script></head><body onLoad=init()>\n\
   <table id=TB width=100%>\n\
   <tr><td></td><td width=90%></td><td></td></tr>\n";
  for (int i=0; i<6;i++){
    form=form+"<tr><td>"+String(i)+"</td>\n\
    <td><input type=range onChange=rChange("+String(i)+")></td>\n\
    <td><input type=text onChange=tChange("+String(i)+")></td></tr>\n";
  }//for i
  form=form+"</table>\n\
  <input type=submit value='Read' onClick='getData(false)'> . . . . . \n\
  <input type=submit value='Update' onClick='getData(true)'>\n\
  Auto <input id=CB type=checkbox>\n\  
  </body>\n</html>";
  return (form);
}//servoMob

void servo_m() {
  Serial.println("servo_m");
  if (server.args()==0){ //HTML page
    server.send(200,"text/html",servoMob());
  }else{ // GET request 
    String sData=server.arg("data")+" ";
    //Brouser removes end space
    //Serial.print("data="+sData);
    decodeGetData(sData);
    sData="";
    for (int i=0; i<6; i++){
      sData+=String(HoldReg[i+1])+" ";
    }//for
    server.send(200,"text/plain",sData);
    webData=true;      
   }//if else  
  Blink(1);  
}//servo_m

