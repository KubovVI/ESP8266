#include "Script.h"
extern int16_t scrServos[_scrSize][_servoNum];
extern int scrLength;

String scriptTxt(){
  String form="{\n";
  for (int r=0; r<scrLength; r++){
    form+="{";
    for (int c=0; c<_servoNum; c++){
      form+=String(scrServos[r][c]);
      if (c<(_servoNum-1)) form+=",";    
    }//for c
    form+="},\n";
  }//for r  
  form+="};";
  return form;
}//scriptTxt

void script_txt() {
  Serial.print("script_txt ");
  Serial.println("L="+String(scrLength));
  server.send(200,"text/plain",scriptTxt());
}//script_off

