#ifndef SCRIPT_H
#define SCRIPT_H

#include "Arduino.h"
#include <ESP8266WebServer.h>
extern ESP8266WebServer server;
#include "Arm.h"

#define _scrMillis 500
extern boolean scriptOn;
extern int16_t HoldReg[];
#define _scrSize 100
extern int16_t scrServos[_scrSize][_servoNum];

boolean scriptProcessing(boolean cycle);
void scriptSet0();

#endif


