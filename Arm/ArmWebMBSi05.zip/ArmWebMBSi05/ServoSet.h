//#include <ESP8266WebServer.h>
extern ESP8266WebServer server;

extern int minPos[]; 
extern int maxPos[]; 
extern int stepPos[];

extern boolean servoLimited;
extern boolean servoSmooth;

String servoSet(){
  String vSmth=""; if (servoSmooth) vSmth=" checked";
  String vLim=""; if (servoLimited) vLim=" checked";  
  String form="<html>\n<head>\n\
  <meta name='viewport' content='width=device-width, initial-scale=0.5'>\n\
  <style>\n\
  body,table,button,input {font-size:30px; height:40px; text-align:center} \n\
  input[type=text]{width:80px; text-align:right}\n\ 
  input[type=checkbox]{width:30px; height:30px}\n\   
   </style>\n\
<script>\n\
var sData='';\n\
function refreshPage(){ window.location.reload(true);}\n\ 
function sendData(){\n\
  alert('?');\n\
}//sendData\n\     
</script></head><body>\n\
  <h4 align=center>Servo PWM Settings</h4>\n\
  <table id=TB border=3 align=center>\n\
  <tr><td>#</td>";
  for (int i=0; i<6;i++){
    form=form+"<td>"+String(i)+"</td>";
  }//for i
  form=form+"</tr>\n\<tr><td>Min</td>";  
  for (int i=0; i<6;i++){
    form=form+"<td><input type=text value="+String(minPos[i])+"></td>";  
  }//for i
  form=form+"</tr>\n\<tr><td>Max</td>";  
  for (int i=0; i<6;i++){
    form=form+"<td><input type=text value="+String(maxPos[i])+"></td>";  
  }//for i
  form=form+"</tr>\n\<tr><td>dS</td>";  
  for (int i=0; i<6;i++){
    form=form+"<td><input type=text value="+String(stepPos[i])+"></td>";  
  }//for i
  form=form+"</tr>\n\</table>\n\<br>\n\
  <input type=submit value='Read' onClick='refreshPage()'>\n\
  <input type=checkbox id=cSm name='Smooth' value=1"+vSmth+">Smooth \n\
  <input type=checkbox id=cLm name='Limited' value=1"+vLim+">Limited \n\
  <input type=submit value='Dummy' onClick='sendData()'>\n\
  </body>\n</html>";
  return (form);
}//servoSet

void servo_s() {
  Serial.println("servo_s");
  server.send(200,"text/html",servoSet());
  Blink(3);  
}//servo_s
