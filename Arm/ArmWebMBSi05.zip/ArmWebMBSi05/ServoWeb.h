extern int16_t HoldReg[];
//#include <ESP8266WebServer.h>
extern ESP8266WebServer server;

extern boolean webData;
extern boolean servoLimited;
extern boolean servoSmooth;

String servoHTML(){
  String vSmth=""; if (servoSmooth) vSmth=" checked";
  String vLim=""; if (servoLimited) vLim=" checked";  
  String form="<html>\n<head>\n\
  <meta name='viewport' content='width=device-width, initial-scale=0.5'>\n\
  <style>\n\
  body,table,button,input {font-size:30px; height:40px; text-align:center} \n\
  input[type=text]{width:80px; text-align:right}\n\ 
  input[type=checkbox]{width:30px; height:30px}\n\   
   </style>\n\
<script>\n\
var sData='';\n\
function packData(){\n\
  sData='';\n\
  tbSize=TB.rows.length-1;\n\
  for (r=0; r<tbSize; r++){\n\
    for (c=0; c<6; c++){\n\
      sData+=parseInt(TB.rows[r+1].cells[c+1].children[0].value)+' ';\n\ 
    }//for c\n\
  }//for r\n\
}//packData\n\
function refreshPage(){ window.location.reload(true);}\n\  
function sendData(){\n\
  sCommand='?';\n\
  if (cSm.checked) sCommand+='Smooth=1&';\n\ 
  if (cLm.checked) sCommand+='Limited=1&';\n\
  packData();\n\
  sCommand+='data=';\n\ 
  //alert(sCommand+sData);\n\
  var xhttp=new XMLHttpRequest();\n\
  xhttp.open('GET',sCommand+sData,true);\n\
  xhttp.send();\n\
  xhttp.onload=function(){}\n\
}//sendData\n\    
</script></head><body>\n\
  <h4 align=center>Servo</h4>\n\
  <table id=TB border=3 align=center>\n\
  <tr><td>#</td>";
  for (int i=0; i<6;i++){
    form=form+"<td>"+String(i)+"</td>";
  }//for i
  form=form+"</tr>\n\<tr><td>V</td>";  
  for (int i=0; i<6;i++){
    form=form+"<td><input type=text value="+String(HoldReg[i+1])+"></td>";  
  }//for i
  form=form+"</tr>\n\</table>\n\<br>\n\
  <input type=submit value='Read' onClick='refreshPage()'>\n\
  <input type=checkbox id=cSm name='Smooth' value=1"+vSmth+">Smooth \n\
  <input type=checkbox id=cLm name='Limited' value=1"+vLim+">Limited \n\
  <input type=submit value='Update' onClick='sendData()'>\n\
  </body>\n</html>";
  return (form);
}//servoHTML

void decodeGetData(String sData){
  if (sData.length()==0) return;
  int s,e; s=0;
  Serial.print("HR[1-6]="); 
  for (int i=0; i<6; i++){
    e=sData.indexOf(" ",s);
    if (e<=0) break;
    HoldReg[i+1]=sData.substring(s,e).toInt();
    Serial.print(HoldReg[i+1]); Serial.print(";");
    s=e+1;
  }//for 
  Serial.println(); 
}//decodeGetData

void servo_w() {
  Serial.println("servo_w");
  if (server.args()==0){ //HTML page
    server.send(200,"text/html",servoHTML());
  }else{ // GET request 
    servoSmooth=(server.arg("Smooth")=="1");
    servoLimited=(server.arg("Limited")=="1");
    if (servoSmooth) Serial.print(" Smooth ");
    if (servoLimited) Serial.print(" Limited ");
    String sData=server.arg("data")+" ";
    //Brouser removes end space
    //Serial.print("data="+sData);
    decodeGetData(sData);
    server.send(200,"text/plain","Ok");
    webData=true;      
   }//if else  
  Blink(3);  
}//servo_w

