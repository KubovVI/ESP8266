#include "Script.h"
extern int16_t scrServos[_scrSize][_servoNum];
extern int scrLength;
extern int scrPoint;
extern boolean scriptOn;

String scriptHTML(){
  String form="<html>\n<head>\n<style>\n\
  body,table,button,input {font-size:30px; height:40px; text-align:center} \n\
  input[type=text]{width:80px; text-align:right}\n\
  .redB {background-color: #ffc0c0}\n\ 
  .grnB {background-color: #c0ffc0}\n\ 
   </style>\n\
<script>\n\
var sData='';\n\
function packData(){\n\
  sData='';\n\
  tbSize=TB.rows.length-1;\n\
  for (r=0; r<tbSize; r++){\n\
    for (c=0; c<6; c++){\n\
      sData+=parseInt(TB.rows[r+1].cells[c+1].children[0].value)+' ';\n\ 
    }//for c\n\
  }//for r\n\
}//packData\n\
function unpackData(){\n\
  //alert(sData);\n\
  var adata=sData.split(' ');\n\
  tbSize=TB.rows.length-1;\n\
  i=0;\n\
  for (r=0; r<tbSize; r++){\n\
    for (c=0; c<6; c++){\n\
      TB.rows[r+1].cells[c+1].children[0].value=adata[i];\n\ 
      i++;\n\
    }//for c\n\
  }//for r\n\
}//unpackData\n\
function getX(send,wr,stp){\n\
  tbSize=TB.rows.length-1;\n\
  sCommand='?';\n\
  if (stp) sCommand+='stop=1&';\n\ 
  if (wr) sCommand+='wr=1&';\n\ 
  sCommand+='len='+tbSize;\n\
  sCommand+='&data=';\n\ 
  if (send) packData(); else sData='';\n\
  var xhttp=new XMLHttpRequest();\n\
  xhttp.open('GET',sCommand+sData,true);\n\
  xhttp.send();\n\
  xhttp.onload=function(){\n\
    sData=this.responseText.trim();\n\
    unpackData();\n\   
  }//onload\n\  
}//getX\n\ 
function readData(){ getX(false,false,false);}//readData\n\ 
function updateData(){ getX(true,false,false);}//updateData\n\
function writeData(){ getX(true,true,false);}//writeData\n\ 
function stopScr(){ getX(false,false,true);}//writeData\n\ 
function addRow(){\n\
  rLast=TB.rows.length-1;\n\
  var Row=TB.insertRow(-1);\n\
  var Cell=[]; Cell[0]=Row.insertCell(0);\n\ 
  rowN=TB.rows.length-2; Cell[0].innerHTML=rowN;\n\
  for (c=0;c<6;c++){\n\
    Cell[c+1]=Row.insertCell(c+1);\n\
    v=TB.rows[rLast].cells[c+1].children[0].value;\n\
    Cell[c+1].innerHTML ='<input type=text value='+v+'>';\n\ 
  }//for c\n\
}//addRow\n\  
function deliteRow(){\n\
  if (TB.rows.length<3) return;\n\
  TB.deleteRow(TB.rows.length-1);\n\
}//deliteRow\n\ 
</script></head><body>\n\
  <table id=TB border=3>\n\
  <tr><td># \\ s</td>";
  for (int c=0; c<_servoNum; c++){
    form=form+"<td>"+String(c)+"</td>";
  }//for c
  form=form+"</tr>\n";
  for (int r=0; r<scrLength; r++){
    form=form+"<tr><td>"+String(r)+"</td>";  
    for (int c=0; c<_servoNum; c++){
      form=form+"<td><input type=text value="+String(scrServos[r][c])+"></td>";  
    }//for c
    form=form+"</tr>\n";
  }//for r   
  form=form+"</table>\n\
  <table><tr><td>\n\
  <input type=submit class=redB value='Stop' onClick='stopScr()'>\n\
  <input type=submit value='Restore' onClick='readData()'>\n\
  <input type=submit value='DelRow' onClick='deliteRow()'>\n\
  <input type=submit value='AddRow' onClick='addRow()'>\n\
  <input type=submit  class=grnB value='Update' onClick='updateData()'>\n\
   </td></tr></table>\n\
  </body>\n</html>";
  return (form);
}//scriptHTML

void decodeGetDataS(String sData, int rSize){
  if (sData.length()==0) return;
  int s,e; s=0;
  Serial.println("script"); 
  for (int r=0; r<rSize; r++){
    for (int c=0; c<_servoNum; c++){
      e=sData.indexOf(" ",s);
      if (e<=0) break;
      scrServos[r][c]=sData.substring(s,e).toInt();
      Serial.print(scrServos[r][c]); Serial.print(" ");
      s=e+1;
    }//for c
    Serial.print("/ "); 
  }//for r
  Serial.println();
}//decodeGetDataS

void script_w() {
  bool wr=false;
  bool stp=false;
  Serial.println("script_w");
  if (server.args()==0){ //HTML page
    server.send(200,"text/html",scriptHTML());
  }else{ // GET request 
    if (server.arg("stop")=="1") stp=true;
    if (server.arg("wr")=="1") wr=true;
    int rSize=server.arg("len").toInt();
    if (rSize>=_scrSize) rSize=_scrSize;
    Serial.print("L="+String(rSize)+" ");
    String sData=server.arg("data");
    //Serial.print("data="+sData+".");
    if (sData.length()>0) {
      decodeGetDataS(sData+" ",rSize);
      scrLength=rSize;
      scriptOn=true;
      if (!wr) scrPoint=0;//start script from begin 
    }//
    if (wr){
      Serial.println("*** Write ***");
    }//if wr
    if (stp){
      Serial.println("*** Stop ***");
      scriptOn=false;
    }//if stp
    
    sData="";
    for (int r=0; r<rSize; r++){
      for (int c=0; c<_servoNum; c++){
        sData+=String(scrServos[r][c])+" ";
      }//for c
    }// for r  
    server.send(200,"text/plain",sData);
   }//if else  
  Blink(3);  
}//script_w

void script_off() {
  Serial.println("script_off");
  scriptOn=false;  
  server.send(200,"text/plain","Scripts Off");
}//script_off


