extern int16_t HoldReg[];
//#include <ESP8266WebServer.h>
extern ESP8266WebServer server;

extern boolean webData;

String servoHTML(){
  String form="<html>\n<head>\n<style>\n\
  body,table,button,input {font-size:30px; height:40px; text-align:center} \n\
  input[type=text]{width:80px; text-align:right}\n\ 
   </style>\n\
<script>\n\
var sData='';\n\
function packData(){\n\
  sData='';\n\
  tbSize=TB.rows.length-1;\n\
  for (r=0; r<tbSize; r++){\n\
    for (c=0; c<6; c++){\n\
      sData+=parseInt(TB.rows[r+1].cells[c+1].children[0].value)+' ';\n\ 
    }//for c\n\
  }//for r\n\
}//packData\n\
function unpackData(){\n\
  //alert(sData);\n\
  var adata=sData.split(' ');\n\
  tbSize=TB.rows.length-1;\n\
  i=0;\n\
  for (r=0; r<tbSize; r++){\n\
    for (c=0; c<6; c++){\n\
      TB.rows[r+1].cells[c+1].children[0].value=adata[i];\n\ 
      i++;\n\
    }//for c\n\
  }//for r\n\
}//unpackData\n\
function getData(send){\n\
  if (send)packData(); else sData='';\n\
  var xhttp=new XMLHttpRequest();\n\
  xhttp.open('GET','?data='+sData,true);\n\
  xhttp.send();\n\
  xhttp.onload=function(){\n\
    sData=this.responseText.trim();\n\
    unpackData();\n\   
  }//onload\n\
}//getData\n\    
</script></head><body>\n\
  <h4 align=center>Servo</h4>\n\
  <table id=TB border=3 align=center>\n\
  <tr><td>#</td>";
  for (int i=0; i<6;i++){
    form=form+"<td>"+String(i)+"</td>";
  }//for i
  form=form+"</tr>\n\<tr><td>V</td>";  
  for (int i=0; i<6;i++){
    form=form+"<td><input type=text value="+String(HoldReg[i+1])+"></td>";  
  }//for i
  form=form+"</tr>\n\</table>\n\<br>\n\
  <input type=submit value='Read' onClick='getData(false)'>...\n\
  <input type=submit value='Update' onClick='getData(true)'>\n\
  </body>\n</html>";
  return (form);
}//servoHTML

void decodeGetData(String sData){
  if (sData.length()==0) return;
  int s,e; s=0;
  Serial.print("HR[1-6]="); 
  for (int i=0; i<6; i++){
    e=sData.indexOf(" ",s);
    if (e<=0) break;
    HoldReg[i+1]=sData.substring(s,e).toInt();
    Serial.print(HoldReg[i+1]); Serial.print(";");
    s=e+1;
  }//for 
  Serial.println(); 
}//decodeGetData

void servo_w() {
  Serial.println("servo_w");
  if (server.args()==0){ //HTML page
    server.send(200,"text/html",servoHTML());
  }else{ // GET request 
    String sData=server.arg("data")+" ";
    //Brouser removes end space
    //Serial.print("data="+sData);
    decodeGetData(sData);
    sData="";
    for (int i=0; i<6; i++){
      sData+=String(HoldReg[i+1])+" ";
    }//for
    server.send(200,"text/plain",sData);
    webData=true;      
   }//if else  
  Blink(3);  
}//servo_w

