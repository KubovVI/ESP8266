#ifndef ARM_H
#define ARM_H
#include <Arduino.h>
#define _servoNum 6

extern boolean servoLimited;
extern boolean servoSmooth;

void armBegin();
void armProcessing();
boolean servosReady();
void servosOff();
#endif

