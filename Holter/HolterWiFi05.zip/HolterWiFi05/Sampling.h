#include "WiFiProc.h"
#include "SDfile.h"

void ICACHE_RAM_ATTR Sampling();
void setupTimer(unsigned long sps);
