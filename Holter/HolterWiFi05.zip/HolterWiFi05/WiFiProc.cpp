#include "WiFiProc.h"
#include "HTMLcode.h"

extern int recTimeM;//24h*60m
extern int flushPeriodS;//80s*200sps*2B*2ch=64000=512B*125
int smplRate; //sps
int smplTime; //ms

#include <Ticker.h>
Ticker myTicker;
void setupTimer(unsigned long sps);
void ICACHE_RAM_ATTR Sampling();

uint16_t wDatas[2][_dataSize+1];
int rBank, wBank, wIndex;
int ringIndex;
bool bankReady=false;
bool Cardio=true;

char Info[_infoLength];

#include "ESP8266WiFi.h"
// WebSocketsServer needs Hash
//This needs to prevent Error on WStype_t type
void wsEvent(uint8_t num, WStype_t type, uint8_t * payload, size_t lenght);
#include <ESP8266WebServer.h>
ESP8266WebServer server(80);
WebSocketsServer ws(81);
String serverIP;
IPAddress clientIP; //maybe Array?

bool onClient[WEBSOCKETS_SERVER_CLIENT_MAX];
bool wsConnected=false;
uint32_t cTime_ms;

void wsEvent(uint8_t num, WStype_t type, uint8_t * payload, size_t lenght) {
  int clients;
  Serial.println();
  Serial.print("Event on "); Serial.print(num,DEC); Serial.print(":");
  switch(type) {
     case WStype_ERROR:
         Serial.println("Error!!!");
         break;          
    case WStype_DISCONNECTED: 
         onClient[num]=false;  
         Serial.println("Disconnected!");
         onClient[num]=false;  
         break;
    case WStype_CONNECTED: wsConnected=true; clientIP= ws.remoteIP(num);
         onClient[num]=true;  
         Serial.print(" Connected to ");
         for (int i=0; i<4; i++){ Serial.print(clientIP[i],DEC); Serial.print("."); } 
         Serial.println(); 
         break;
   case WStype_TEXT:
         int iMax=lenght; if (iMax>_infoLength) iMax=_infoLength; 
         String s=""; 
         for (int i=0; i<iMax; i++) {
           Info[i]=payload[i];
           s=s+char(payload[i]);
         }// for i
         Serial.println(s);        
         cTime_ms=millis();
         //Serial.print(cTime_ms,DEC); Serial.println("ms");
         break;
  }//switch
}//wsEvent

void handle_root() {
  server.send(200,"text/html",formHTML());
  Serial.println("handle_root");
}//handle_root

void handle_test() {
  Serial.println("handle_test");
  if (server.args()>0){
    if (server.arg("mode")=="Timer") { Serial.println("Timer");
      Cardio=false;
    }//if Timer
    if (server.arg("mode")=="Cardio") { Serial.println("Cardio");
      Cardio=true;  
    }//if Cardio
    if (server.arg("int")=="Switch") { Serial.println("IntrptSwitch");
      IntrptSwitch=true;
    }//if int
    if (server.arg("int")=="noSwitch") { Serial.println("noIntrptSwitch");
      IntrptSwitch=false;
    }//if int
    recTimeM=server.arg("recTime").toInt();
    Serial.print("recTime="); Serial.println(recTimeM,DEC);
    flushPeriodS=server.arg("flushTime").toInt();
    Serial.print("flushTime="); Serial.println(flushPeriodS,DEC); 
    smplRate=server.arg("sps").toInt();
    Serial.print("smplRate="); Serial.println(smplRate,DEC); 
    smplTime=server.arg("spms").toInt();
    Serial.print("smplTime="); Serial.println(smplTime,DEC); 
      
    //server.send(200,"text/html",formHTML());// old URI
    server.sendHeader("Location","/"); server.send(303); //redirect to root
  } else server.send(200,"text/html",testHTML());
}//handle_test

void setupWiFi(){
  //This needs only at first time to disable Station mode
  //WiFi.mode(WIFI_STA); WiFi.disconnect(); //Disable Station Mode
  delay(100);
  WiFi.softAP(_ssid,_pass); // set password if needs
  //WiFi.softAP(_ssid);
  serverIP=WiFi.softAPIP().toString();
  Serial.println(serverIP);

  ws.begin();
  ws.onEvent(wsEvent);
 
  server.on("/", handle_root);
  server.on("/test", handle_test);
 
  server.begin();
  Serial.println("HTTP server started");

  wBank=0; wIndex=0; bankReady=false;
  ringIndex=0;
   
  for (uint8_t num=0; num<WEBSOCKETS_SERVER_CLIENT_MAX; num++) 
     onClient[num]=false;
}//setupWiFi

void WiFiLoop(){
  ws.loop();
  server.handleClient();
  //------- Web Sockets ----------
  if (bankReady){ bankReady=false;
    wDatas[rBank][_dataSize]=ringIndex; 
    wsBroadcast();
    ringIndex++; 
    if (ringIndex>=_ringSize){ ringIndex=0;
      Serial.println();
    }//if ringIndex
  }//if bankReady  
}//WiFiLoop

void wsBroadcast(){
  for (uint8_t num=0; num<WEBSOCKETS_SERVER_CLIENT_MAX; num++){
    if (onClient[num]){
      Serial.print("."); // Test
      if (!ws.sendBIN(num,(uint8_t*)&wDatas[rBank][0],_dataSize*2+2)){
        ws.disconnect(num);
        onClient[num]=false;
        Serial.print("Error on "); Serial.println(num,DEC);
     }//if  ws.send
    }//if onClient 
  }//for num
  if (ws.connectedClients()<1) wsConnected=false;
}//wsBroadcast

void switchToTimer1(){
  myTicker.detach();    
  setupTimer(_smplRate); 
}//switchToTimer1

void switchToTicker(){
  timer1_detachInterrupt();  
  myTicker.attach_ms(_smplTime, Sampling);      
}//switchToTicker

void WiFiOff(){
  ws.close();
  WiFi.forceSleepBegin(); delay(4); // Turn off WiFi radio 
  Serial.println("WiFi Off"); 
}//WiFiOff

void WiFiOn(){
  WiFi.forceSleepWake(); delay(4); // Turn on WiFi radio  
  Serial.println("WiFi On"); 
  ws.begin();
}//WiFiOn


