#define _ssid "EspHolter1"
#define _pass "123456789"

#include <WebSocketsServer.h>
#include <Hash.h>

#define _smplRate 200 //sps
#define _smplTime 5 // 1000ms/200
extern int smplRate; //sps
extern int smplTime; //ms

#define _dataSize 100
#define _segSize 10
#define _ringSize 100

#define _infoLength 64

void wsEvent(uint8_t num, WStype_t type, uint8_t * payload, size_t lenght);

void setupWiFi();
void WiFiLoop();
void wsBroadcast();

void WiFiOff();
void WiFiOn();

void switchToTimer1();
void switchToTicker();

