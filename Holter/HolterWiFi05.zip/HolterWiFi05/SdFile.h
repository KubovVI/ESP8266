#include "WiFiProc.h"
#include <SPI.h>
#include <SD.h>
#define _SD_CS 15

#define _swPin 16
#define _LedPin 2

#define _Mask "Rec****.bin"
#define _maxFileNumber 9999
String nextFileName(String mask); 

#define _countMax 17280000 //200*60*60*24=17280000
#define _portionMax  64000 //512*125 200sps*80s*4byte
extern uint32_t countMax;
extern uint32_t portionMax;

#define _bufSize 100
extern uint16_t Buffer[_bufSize][2];
extern int pWrite, pRead;

extern boolean RecordOn;
boolean testRecordMode();
void writeData();
void writeHeader();
void setRecSizes();

//------------ Record status Led indication ---------------
extern int LedTick, LedPeriod, LedOff;
void setLed_Ok();
void setLed_Error();
void setLed_Stop();
void setLed_Off();

