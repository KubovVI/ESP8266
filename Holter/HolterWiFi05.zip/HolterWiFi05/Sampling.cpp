#include "Sampling.h"

extern uint16_t wDatas[2][_dataSize+1];
extern int rBank, wBank, wIndex;
extern int ringIndex;
extern bool bankReady;
extern bool Cardio;

extern uint16_t Buffer[_bufSize][2];
extern int pWrite, pRead;
extern boolean RecordOn;
extern int LedTick, LedPeriod, LedOff;

void ICACHE_RAM_ATTR Sampling(){
  uint16_t data=analogRead(0);
  if (!Cardio) data=millis() % 1024;
  //------------ SD record --------------
  if (RecordOn){
    Buffer[pWrite][0]=millis();
    Buffer[pWrite][1]=data; 
    pWrite++;
    if (pWrite>=_bufSize) pWrite=0;
  }//if RecordOn 
  //----------- Led blink -------------- 
  LedTick++; 
  if (LedTick>=LedPeriod) { LedTick=0; digitalWrite(_LedPin,LOW);}
  if (LedTick==LedOff) digitalWrite(_LedPin,HIGH); 
  //------------ Web Socket Data --------
  wDatas[wBank][wIndex]=data;
  wIndex++;
  if (wIndex>=_dataSize){
    wIndex=0; rBank=wBank; wBank=1-wBank; //wBank=0..1
    bankReady=true;
  }//if wIndex
}//Sampling

void setupTimer(unsigned long sps){
  timer1_attachInterrupt(Sampling); 
  timer1_enable(TIM_DIV16, TIM_EDGE, TIM_LOOP);
  // 80MHz/div16 -> 80MHz/16=5MHz=5000KHz 
  timer1_write(5000000/sps); 
}//setupTimer

