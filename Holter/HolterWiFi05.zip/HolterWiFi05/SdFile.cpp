#include "SDfile.h"

#define _smplSize 4; //2byte*2ch

extern int recTimeM;//24h*60m
extern int flushPeriodS;//80s*200sps*2B*2ch=64000=512B*125
uint32_t countMax;
uint32_t portionMax;

boolean RecordStop=false;

extern char Info[_infoLength];

String nextFileName(String mask){
  char mLength=mask.length();
  char mS1=mask.indexOf("*"); char mS2=mask.lastIndexOf("*");
  String mPrefix=mask.substring(0,mS1);
  String mPostfix=mask.substring(mS2+1);
  String cName;
  int maxNumber=-1;
  File root=SD.open("/");
  Serial.println("--- SD files ---");
  while (1){
    File entry=root.openNextFile();
    if (!entry) break; //exit
    cName=entry.name();
    Serial.println(cName);
    if (cName.length()==mask.length()){
      if ((cName.substring(0,mS1)==mPrefix) && (cName.substring(mS2+1)==mPostfix)){
        int n=cName.substring(mS1,mS2+1).toInt();
        if (n>maxNumber) maxNumber=n;
      }// if substring
    }// if length
  }//while
 Serial.println("----------------");
  maxNumber++;
  if (maxNumber>_maxFileNumber) maxNumber=_maxFileNumber;
  String sNumber=String(maxNumber,DEC);
  char sNlength=mS2-mS1+1;
  while (sNumber.length()<sNlength) sNumber="0"+sNumber;
  return mPrefix+sNumber+mPostfix;
}//nextFileName

File file;
String fileName;
extern boolean RecordOn=false;

uint16_t Buffer[_bufSize][2];
extern int pWrite=0;
extern int pRead=0;
extern uint32_t count=0; 
extern uint32_t portion=0; 
extern bool IntrptSwitch;
extern uint32_t cTime_ms;

boolean testRecordMode(){
   // ----------------- Test Switch -----------------------
  if ( (!RecordOn) && (!digitalRead(_swPin)) ){
    setRecSizes();
    pWrite=0; pRead=0;
    RecordOn=true; 
    WiFiOff(); // ================================
    if (IntrptSwitch) switchToTimer1();
    RecordStop=false;
    if (!SD.begin(_SD_CS)) {
      Serial.println("SD Error!");
      setLed_Error();
      RecordStop=true;
      return RecordOn;
      //while(1)delay(1);//halt
    }//if SD.begin

    Serial.println("Record On");
    fileName=nextFileName(_Mask);
    Serial.println(fileName);
    file = SD.open(fileName, FILE_WRITE); //append
    if (!file){
      Serial.println("File Error!");
      setLed_Error();
      RecordStop=true;
      return RecordOn;
      //while(1)delay(1);//halt
    }//if file

    Serial.println("Start to write");
    count=0; portion=0;
    setLed_Ok();
    
    writeHeader();
  }//Record
  
  if ( (RecordOn) && (digitalRead(_swPin)) ){ RecordOn=false;
    if (IntrptSwitch) switchToTicker();
    WiFiOn(); //=======================================
    Serial.println("Record Off");  
    setLed_Stop();
    if (RecordStop) return RecordOn;  
    file.flush(); //save on SD
    file.close();
    Serial.println("File Close");
  }//not Record
  return RecordOn;
}//testRecordMode

void writeData(){
  if (RecordStop) return;
  int n;
  while (pRead!=pWrite){ // Read Buffer
    n=file.write((uint8_t*)&Buffer[pRead][0],4); // 2words*2byte
    if (n<=0) { RecordStop=true;
      setLed_Error();   
      Serial.print("SD Error");
      return;
    }//if n  
    pRead++; if (pRead>=_bufSize) pRead=0;
    count++;
    portion+=_smplSize;
    if (portion>=portionMax){
      portion=0;
      file.flush(); //save on SD
      Serial.print("*");    
    }//if portion
  }//while
  if (count>countMax){
    file.close();
    Serial.println("Stop");
    setLed_Stop();
    RecordStop=true;
   }// if count  
}//writeData

void writeHeader(){
  uint8_t infoLength=_infoLength;
  file.write((uint8_t*)&infoLength,1); 
  uint8_t smplSize=_smplSize;
  file.write((uint8_t*)&smplSize,1); 
  uint16_t smplRate=_smplRate;
  file.write((uint8_t*)&smplRate,2); 
  uint32_t dTime=millis()-cTime_ms; // delay
  file.write((uint8_t*)&dTime,4); 
  file.write((char*)&Info[0],_infoLength-8); 
  file.flush(); //save on SD
  Serial.print(infoLength,DEC); Serial.print("b ");
  Serial.print(smplSize,DEC); Serial.print("b ");
  Serial.print(smplRate,DEC); Serial.print("sps ");
  Serial.print(dTime,DEC); Serial.println("ms");
  
  portion=infoLength;
}//writeInfo

void setRecSizes(){
  portionMax=flushPeriodS*_smplRate*_smplSize; 
  countMax=recTimeM*60*_smplRate*_smplSize;
  Serial.println();
  Serial.print("portionMax="); Serial.print(portionMax,DEC);
  Serial.print("; countMax="); Serial.println(countMax,DEC);
}//setRecSizes

//------------ Record status Led indication ---------------
extern int LedTick=0; 
extern int LedPeriod=200; 
extern int LedOff=5;
void setLed_Ok(){ LedPeriod=200; LedOff=5;}
void setLed_Error(){ LedPeriod=50; LedOff=1;}
void setLed_Stop(){ LedPeriod=1000; LedOff=5;}
void setLed_Off(){ LedPeriod=1000; LedOff=0;}

