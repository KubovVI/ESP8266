void cnsHlpHTML(){
  HTMLstring=F("<html>\n<head>\n\
<meta name='viewport' content='width=device-width, initial-scale=0.5'>\n\
<style>\n\
body,table{font-size:20px}\n\
</style></head><body>\n\
<table border=1 cellpadding=5 align=center>\n\
<tr><td colspan=4 align=center><b>Generator Console Commands</b></td></tr>\n\
<tr><td colspan=3 bgcolor=#ff8080><b>S</b></td><td>Stop Generator Output</td></tr>\n\
<tr><td colspan=3 bgcolor=#80ff80><b>R</b></td><td>Run Generator Output</td></tr>\n\
<tr><td rowspan=7 bgcolor=#ffff00><b>F</b></td><td>N</td><td>XXX</td>\n\
<td>Number of Frequencies</td></tr>\n\
<tr><td>L</td><td>XXXX.XX</td><td>Low Frequency (Hz)</td></tr>\n\
<tr><td>H</td><td>XXXX.XX</td><td>High Frequency (Hz)</td></tr>\n\
<tr><td>P</td><td>XXX</td><td>Number of Periods</td></tr>\n\
<tr><td>D</td><td>XXX</td><td>Delay before Averaging (ms)</td></tr>\n\
<tr><td rowspan=2>S</td><td>E/L</td><td>Scan type Exp(Log)/Line</td></tr>\n\
<tr><td>S/B</td><td>Scan Single/Bi-direction</td></tr>\n\
<tr><td rowspan=2 bgcolor=#a0a0ff><b>A</b></td><td>N</td><td>XXX</td>\n\
<td>Amplitude Zero Level</td></tr>\n\
<tr><td colspan=2>L/H</td><td>Low/Hi Sensitivity (A/2)/(A)</td></tr>\n\
<tr><td bgcolor=#ff8080><b>B</b></td><td colspan=2>0/1</td>\n\
<td>Serial Speed 39400/57600 (Baud)</td></tr>\n\
<tr><td colspan=3 bgcolor=#f0f0f0><b>*</b></td>\n\
<td>Insert * at the Scan Beginnig</td></tr>\n\
<tr><td colspan=3 bgcolor=#f0f0f0><sub><u>Space</u></sub></td>\n\
<td>Remove * at the Scan Beginnig</td></tr>\n\
<tr><td colspan=4 align=right>Web-Console Adds Symbol \\n at the Command End.\n\
<br>There are no difference on Up/Lo Kbd-register.\n\
<br>Goto <a href=/cons>Console</a></td></tr></table>\n\
</body>");
}//cnsHlpHTML

/*
 */
