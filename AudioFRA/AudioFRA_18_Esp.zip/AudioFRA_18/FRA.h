void fraHTML1(){
  HTMLstring=F("<html>\n<head>\n\
<meta name='viewport' content='width=device-width, initial-scale=0.5'>\n\
<style>\n\
body,table,button,input {font-size:20px; height:22px; text-align:center} \n\
input[type=text]{width:70px; text-align:left; border:none}\n\ 
input[type=checkbox]{width:20px; height:20px}\n\
input[type=button]{height:24px}\n\ 
div {position:absolute; right:5px; top:5px}\n\
</style>\n\
<script>\n\
RxGo=true; RxS=''; TxS=''; sBuff='';\n\
ws=new WebSocket('ws://192.168.4.1:81/');\n\
ws.onmessage=function(msg){\n\
  ws.binaryType='arraybuffer';\n\
  if (msg.data instanceof ArrayBuffer){\n\
    Buffer=new Uint8Array(msg.data);\n\
    RxS=String.fromCharCode.apply(null,Buffer);\n\ 
    decodeRxS();\n\
  }//if msg.data\n\ 
}//onmessage \n\
dB=0; Phi=0; fwork=1;\n\
grBusy=false;\n\
function Grid(){\n\ 
  gr.clearRect(0,0,picW,picH);\n\
  gr.strokeStyle='#8080ff';\n\
  if (fLog) GridXlog(); else GridXlin();\n\
  GridY();\n\ 
}//Grid\n\
function GridXlog(){\n\
  f=1;\n\
  for(i=0; i<=4; i++){\n\
    if ((f>=fmin)&&(f<=fmax)){\n\
      gr.lineWidth=3;\n\ 
      x=fToX(f); gr.strokeRect(x,0,0,picH);\n\  
    }//if\n\
    gr.lineWidth=1;\n\ 
    for (j=2; j<=9; j++){ fj=f*j;\n\     
      if ((fj>=fmin)&&(fj<=fmax)){\n\
        x=fToX(fj); gr.strokeRect(x,0,0,picH);\n\
      }//for j\n\      
    }//for j\n\
    f=f*10;\n\
  }//for i\n\   
}//GridXlog\n\
function stepX(xMin,xMax){\n\
  var dx=(xMax-xMin)/10;\n\
  var m=Math.pow(10,Math.floor(Math.log10(dx)));\n\ 
  var x=dx/m;\n\ 
  var r=1; if (x>7.5) r=10; else if (x>3.5) r=5;\n\ 
  else if (x>1.5) r=2;\n\
  return r*m;\n\
}//stepX\n\
function GridXlin(){\n\
  df=stepX(fmin,fmax)\n\
  imin=Math.ceil(fmin/df); imax=Math.floor(fmax/df);\n\
  for (i=imin; i<=imax;i++){x=fToX(i*df);\n\
   gr.strokeRect(x,0,0,picH);\n\
  }//for i\n\
}//GridXlin\n\ 
function GridY(){\n\
  gr.lineWidth=2;\n\ 
  for(i=-3; i<=6; i++){\n\
    y=dBtoY(i*10); gr.strokeRect(0,y,picW,0);\n\
  }//for i\n\
  gr.lineWidth=1;\n\ 
  for(i=-3; i<=5; i++){\n\
    y=dBtoY(i*10+5); gr.strokeRect(0,y,picW,0);\n\
  }//for i\n\
  gr.lineWidth=3;\n\ 
  for(i=0; i<=1; i++){\n\
    y=dBtoY(i*50); gr.strokeRect(0,y,picW,0);\n\
  }//for i\n\
  gr.lineWidth=2; gr.strokeStyle='#ff0000';\n\
  y=PhiToY(0); gr.strokeRect(0,y,picW,0);\n\
}//GridY\n\     
function remap(x,xMin,xMax,yMin,yMax){\n\
  return(yMin+(yMax-yMin)*(x-xMin)/(xMax-xMin));\n\
}//remap\n\
function fToX(f){\n\
  if(fLog){Lnf=Math.log(f);\n\ 
    x=remap(Lnf,Lnfmin,Lnfmax,Xmin,Xmax);\n\  
  } else x=remap(f,fmin,fmax,Xmin,Xmax);\n\  
  return x;\n\
}//fToX\n\
function dBtoY(db){\n\
  return (remap(db,dBmin,dBmax,Ymin,Ymax));}\n\
function PhiToY(p){\n\
  return (remap(p,Phimin,Phimax,Ymin,Ymax));}\n\
function Graph(){\n\
  if (grBusy)  return;\n\
  grBusy=true;\n\
  gr.lineWidth=1;\n\
  x=fToX(fwork); y=dBtoY(dB);\n\
  gr.fillStyle='#000000'; gr.fillRect(x-2,y-2,5,5);\n\
  y=PhiToY(Phi);\n\
  gr.strokeStyle='#ff0000'; gr.strokeRect(x-2,y-2,5,5);\n\  
  grBusy=false;\n\
}//Graph\n\
//------------------------------------------------------------------------------\n\
");
}//fraHTML1
void fraHTML2(){
  HTMLstring=F("\n\
function decodeRxS(){\n\
  if (RxS[0]=='#'){\n\
    _inText.value=RxS;\n\
    //sBuff=sBuff+RxS;\n\
   } else if (RxS.length>10){\n\
    _inText2.value=RxS;\n\
    RxV=RxS.split('\\t');\n\
    fwork=eval(RxV[0]); Asin=eval(RxV[1]); Acos=eval(RxV[2]); Aavr=eval(RxV[3]);\n\
    A0=Math.sqrt(Asin*Asin+Acos*Acos); Phi=Math.atan2(Acos,Asin)*180/Math.PI;\n\
    dB=Math.log10(A0)*20;\n\
    Graph();\n\
    sBuff=sBuff+fwork.toFixed(2)+'\\t'+dB.toFixed(2)+'\\t'+Phi.toFixed(2)+'\\n';\n\
  } else {\n\
    _ciklN.value=RxS;\n\
    sBuff=sBuff+RxS;\n\
  }// else\n\     
}//decodeRxS\n\
function sendCTL(s){ ws.send('#'+s); }\n\
function initCTL(){\n\
  RxS='';\n\ 
  fmin=eval(_fmin.value); fmax=eval(_fmax.value); fnum=eval(_fnum.value);\n\
  Lnfmin=Math.log(fmin); Lnfmax=Math.log(fmax);\n\
  fLog=_fLog.checked; if (fLog) sendCTL('fse'); else  sendCTL('fsl');\n\
  sendCTL('fn'+fnum); sendCTL('fl'+fmin); sendCTL('fh'+fmax);\n\ 
  Grid(); \n\
  sDate=DateToStr(true); _Date.value=sDate;\n\
  sBuff='';//clear sBuff\n\   
}//initCTL\n\
function initCTLdelay(){ setTimeout(initCTL,1000);}\n\  
function DateToStr(delimit){\n\
  var Dt=new Date();\n\
  yy=Dt.getFullYear(); mn=Dt.getMonth()+1; dd=Dt.getDate();\n\
  hh=Dt.getHours(); mm=Dt.getMinutes();\n\ 
  var s=yy; if (delimit)s=s+'.';\n\ 
  if (mn<10) s=s+'0'; if (delimit)s=s+mn+'.';\n\ 
  if (dd<10) s=s+'0'; if (delimit)s=s+dd+' ';\n\
  if (hh<10) s=s+'0'; s=s+hh; if (delimit)s=s+':';\n\ 
  if (mm<10) s=s+'0'; s=s+mm;\n\
  return s;\n\
}//DateToStr\n\
function saveFile(){\n\
  fName='FRA'+DateToStr(false)+'.txt';\n\
  sHeader=_Date.value+'\\n'+_inText.value+'\\n---------------\\n';\n\
  sBuff=sHeader+sBuff;\n\    
  tBlob=new Blob([sBuff],{type:'text/plain'});\n\
  aLink=document.createElement('a'); aLink.download=fName;\n\
  aLink.href=window.URL.createObjectURL(tBlob);\n\
  document.body.appendChild(aLink); aLink.style.display='none';\n\
  aLink.click();\n\
  sBuff='';//clear sBuff\n\ 
}//saveFile\n\
function clearOld(){ Grid(); sBuff='';}\n\
</script></head>\n\
<body onload=initCTLdelay()>\n\
<input type=text id=_inText style='width:100%; font-size:16px' value=''>\n\
<canvas id=myPic></canvas>\n\
<table width=100%><tr>\n\
<td align=left><input type=text id=_fmin value=10 onchange=initCTL()>\n\
#f:<input type=text id=_fnum value=49 onchange=initCTL()>\n\
<input id=_fLog type=checkbox checked onchange=initCTL()>Log</td>\n\
<td align=center> <input type=button value=Clear onClick=clearOld()></td>\n\
<td align=center><table border=1><tr><td>\n\
<input type=text id=_ciklN style='font-size:16px' value=''>\n\
<input type=text id=_inText2 style='width:300px; font-size:16px' value=''>\n\
</td></tr></table></td>\n\
<td align=center><input type=button value=Save onClick=saveFile()></td>\n\
<td align=right><i>f</i>, Hz &nbsp;\n\ 
<input type=text id=_fmax style='text-align:right' value=1000 onchange=initCTL()></td>\n\
</tr></table>\n\
<script>\n\
winH=window.innerHeight; winW=window.innerWidth;\n\
picH=winH-80; picW=winW-10;\n\
myPic.height=picH; myPic.width=picW;\n\
gr=myPic.getContext('2d');\n\ 
Ymin=picH-5; Ymax=5; Xmin=5; Xmax=picW-5;\n\
fLog=true; fnum=49; fmin=10; fmax=1000;\n\
Lnfmin=Math.log(fmin); Lnfmax=Math.log(fmax);\n\
dBmin=-30; dBmax=60;\n\
Phimin=-180; Phimax=180;\n\
grBusy=false;\n\
Grid();\n\
</script>\n\
<div><input type=text id=_Date style='width:200px; text-align:right' value=''></div>\n\
</body>\n</html>");
}//fraHTML2

/*
 */
