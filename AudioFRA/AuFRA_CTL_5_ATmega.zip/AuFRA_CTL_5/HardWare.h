#include "avr/pgmspace.h"
#define _sinOffset 127
const int8_t sine256[] PROGMEM = {
0,3,6,9,12,16,19,22,25,28,31,34,37,40,43,46,49,51,54,57,60,63,65,68,71,73,76,78,81,83,85,88,90,92,94,96,98,100,
102,104,106,107,109,111,112,113,115,116,117,118,120,121,122,122,123,124,125,125,126,126,126,127,127,127,127,127,
127,127,126,126,126,125,125,124,123,122,122,121,120,118,117,116,115,113,112,111,109,107,106,104,102,100,98,96,
94,92,90,88,85,83,81,78,76,73,71,68,65,63,60,57,54,51,49,46,43,40,37,34,31,28,25,22,19,16,12,9,6,3,0,-3,-6,-9,
-12,-16,-19,-22,-25,-28,-31,-34,-37,-40,-43,-46,-49,-51,-54,-57,-60,-63,-65,-68,-71,-73,-76,-78,-81,-83,-85,-88,
-90,-92,-94,-96,-98,-100,-102,-104,-106,-107,-109,-111,-112,-113,-115,-116,-117,-118,-120,-121,-122,-122,-123,
-124,-125,-125,-126,-126,-126,-127,-127,-127,-127,-127,-127,-127,-126,-126,-126,-125,-125,-124,-123,-122,-122,
-121,-120,-118,-117,-116,-115,-113,-112,-111,-109,-107,-106,-104,-102,-100,-98,-96,-94,-92,-90,-88,-85,-83,-81,
-78,-76,-73,-71,-68,-65,-63,-60,-57,-54,-51,-49,-46,-43,-40,-37,-34,-31,-28,-25,-22,-19,-16,-12,-9,-6,-3
};

const unsigned int TIMER1_PERIOD=416; //416->26us; 400->25us counter
double ref_CLK; //416->38369Hz
volatile byte sin_cnt; // sin index inside interrupt
volatile byte cos_cnt;  
volatile unsigned long sin_phase; // phase accumulator *2^24
volatile unsigned long d_phase; // phase increment *2^24
volatile int8_t sinV,cosV,sinVold,cosVold;
volatile int aInV,aSin,aCos;
volatile long tic_delay; 

volatile unsigned long tic_max;
volatile unsigned long tic_size;
volatile unsigned long tic_cnt;
volatile long sumAs,sumAc,sumAa; 
volatile boolean sumRestart, sumReady;

void setFreq(double f){
  d_phase=0x100000000*f/ref_CLK; // phase increment *2^24
  tic_size=periodsMax*ref_CLK/f;
  tic_max=tic_size+tic_delay+1;
  noInterrupts();  
  sumReady=false; sumRestart=true;
  interrupts();
}//setFreq

void setPWM2out(boolean S){
  if (S) pinMode(11,OUTPUT); else pinMode(11,INPUT);   
}//setPWM2out

void setupTimer2(){
  //prescaller=1, fast PWM 
  TCCR2B=B00000001; TCCR2A=B10000011;  
  setPWM2out(PWM_OUT); //Timer2 output
}//setupTimer2

void setupTimer1(){
    TCCR1A=0; TCCR1B=0; 
    OCR1A=TIMER1_PERIOD; // 400->25us counter
    bitSet(TCCR1B,WGM12); // CTC mode
    bitSet(TCCR1B,CS10);  // scaller 1
    bitSet(TIMSK1,OCIE1A);  // Interrupt enable
}//setupTimer1

ISR(TIMER1_COMPA_vect){
  bitSet(PORTB,5); // Test  13-pin
  OCR2A=sinV+_sinOffset; //set PWM
  //-------------- ADC ------------------
  aInV=ADC; //read ADC
  bitSet(ADCSRA, ADSC); //run new conversion  
  aInV=aInV-aOffset;
  if (HI_SENS){
    if (aInV>256) aInV=256; else if (aInV<-256) aInV=-256;}
  else aInV=aInV>>1; 
  aSin=aInV*sinVold; aCos=aInV*cosVold;
  if (sumRestart){ sumReady=false; sumRestart=false;
    tic_cnt=0; sumAs=0L; sumAc=0L; sumAa=0L; 
  }else{ 
    if (tic_cnt<tic_max){ 
      if (tic_cnt>tic_delay){ 
        sumAs=sumAs+aSin; sumAc=sumAc+aCos;
        sumAa=sumAa+aInV;
      }//if tic_cnt>tic_delay
      tic_cnt++; // count sum
     }else{
      sumReady=true;
    }//if tic_cnt<tic_max 
  }////if sumRestart  
  //-------------- PWM -------------------  
  sinVold=sinV; cosVold=cosV;
  sin_phase=sin_phase+d_phase; //phase
  sin_cnt=sin_phase>>24; //sine table index
  cos_cnt=sin_cnt+64;
  sinV=pgm_read_byte_near(sine256+sin_cnt);
  cosV=pgm_read_byte_near(sine256+cos_cnt);
  bitClear(PORTB,5); // Test  13-pin
}//ISR

void setAnalogRead(byte ADCpin){
  ADCSRB=0; // ADTS[0-2]=0 - Free Running mode
  ADCSRA=bit(ADEN) // Turn ADC on
        //|bit(ADATE) // ADC Auto Trigger Enable
        //|bit(ADIE) // Enable interrupt
        |bit(ADPS0)|bit(ADPS2); // Prescaler=32 T=26us       
  ADMUX=bit(REFS0)|bit(REFS1) // Vref=1.1V
        |((ADCpin)&0x07); // Arduino Uno to ADC pin
  bitSet(ADCSRA, ADSC); //run first conversion  
}//setAnalogRead

void setupHardWare(){
  ref_CLK=16e6/(TIMER1_PERIOD+1);
  tic_delay=ref_CLK*preamb_ms*1e-3;
  setupTimer2();
  setupTimer1();
  setAnalogRead(0); //A0
  setFreq(frMin);
}//setupHardWare
