void printParams();

boolean newCTL(){
  static String sBuff="";
  double x; int i;
  if (!Serial.available()) return false;
  while (Serial.available()){ //read string
    char c=Serial.read();
    //Serial.print(c);
    if (c=='\n'){ //end of string
      sBuff.toUpperCase();
      Serial.println(); Serial.print("#");
      Serial.println(sBuff);     
      switch (sBuff.charAt(0)){ //1-char
        case 'F': //frequencie
          switch (sBuff.charAt(1)){//2-char
            case 'L': //frMin
              sBuff.remove(0,2); x=sBuff.toFloat(); if (x>0)frMin=x;  
              break;      
            case 'H': //frMax
              sBuff.remove(0,2); x=sBuff.toFloat(); if (x>0)frMax=x;  
              break;      
            case 'N': //frNumb
              sBuff.remove(0,2); i=sBuff.toInt(); if (i>0)frNumb=i;  
              break;      
           case 'P': //periodsMax
              sBuff.remove(0,2); i=sBuff.toInt(); if (i>0) periodsMax=i;  
             break;      
            case 'D': //delay preamb_ms 
              sBuff.remove(0,2); x=sBuff.toFloat(); if (x>0) preamb_ms=x;  
              break;      
            case 'S': //Scan type
              switch (sBuff.charAt(2)){ // 3-char
                case'E': SCAN_EXP=true; break;      
                case'L': SCAN_EXP=false; break; 
                case'B': BI_SCAN=true; break; 
                case'S': BI_SCAN=false; break; 
                default: Serial.println("__?"); break; 
              }//switch 3-char              
              break;      
            default: Serial.println("#_??"); break; 
          }//switch 2-char
          break; 
        //----------------------------------
        case 'A': //Amplitude 
          switch (sBuff.charAt(1)){//2-char
            case '0': //aOffset
              sBuff.remove(0,2); i=sBuff.toInt(); if (i>0) aOffset=i;  
              break; 
            case 'L': // Lo sens aIn/2
              HI_SENS=false; break; 
            case 'H': // Hi sens
              HI_SENS=true; break; 
            default: Serial.println("#_??"); break;            
           }//switch 2-char
         break; 
        //----------------------------------
        case '*': //print * in scan head 
          SER_SEP=true; break; 
        case ' ': //donot print * in scan head 
          SER_SEP=false; break; 
        //----------------------------------
        case 'R': //PWM out Run 
          PWM_OUT=true; break; 
        case 'S': //PWM out Stop 
          PWM_OUT=false; break; 
        case 'Z': //List params
          printParams(); 
          break; 
        //----------------------------------
          case 'B': //Bodes Serial
          switch (sBuff.charAt(1)){//2-char
            case '0': 
              Serial.end(); Serial.begin(19200);
              break; 
            case '1': 
              Serial.end(); Serial.begin(38400);
              break; 
            default: Serial.println("#_??"); break;            
           }//switch 2-char
           Serial.flush();  
         break; 
        //----------------------------------      
        default: Serial.println("#???"); break; 
      }//switch 1-char            
      sBuff="";
      return true; 
    }//if end of string
    else sBuff=sBuff+c; 
  }//while Serial.available
  return false;
}//newCTL
