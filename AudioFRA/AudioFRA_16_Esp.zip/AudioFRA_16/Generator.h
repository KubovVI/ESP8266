void genHTML1(){
  HTMLstring=F("<html>\n<head>\n\
<meta name='viewport' content='width=device-width, initial-scale=0.5'>\n\
<style>\n\
body,table,button,input {font-size:30px; height:32px; text-align:center} \n\
input[type=text]{width:120px; text-align:left}\n\ 
input[type=range]{width:100%; height:50px}\n\
input[type=checkbox]{width:24px; height:24px}\n\ 
</style>\n\
<script>\n\
RxGo=true; RxS=''; TxS=''\n\
ws=new WebSocket('ws://192.168.4.1:81/');\n\
ws.onmessage=function(msg){\n\
  ws.binaryType='arraybuffer';\n\
  if (msg.data instanceof ArrayBuffer){\n\
    Buffer=new Uint8Array(msg.data);\n\
    RxS=String.fromCharCode.apply(null,Buffer);\n\ 
    decodeRxS();\n\
    Draw();\n\
  }//if msg.data\n\ 
}//onmessage \n\
Amin=-512; Amax=512; Asin=400; Acos=400; grScale=1;\n\
dB=55; dBmin=-1.2; dBmax=51.2;\n\
grBusy=false;\n\
function Draw(){\n\
  if (grBusy)  return;\n\
  grBusy=true;\n\
  gr.clearRect(0,0,picW+picBorder,picH);\n\
  Grid();\n\
  Graph();\n\
  grBusy=false;\n\
}//Draw\n\
function Grid(){\n\ 
  gr.lineWidth=1; gr.strokeStyle='#8080ff';\n\ 
  //gr.strokeRect(1,1,picW-2,picH-2);\n\
  for(i=-5; i<=5; i++){\n\
    x=remap(i*100*grScale,Amin,Amax,Xmin,Xmax);\n\
    gr.strokeRect(x,0,0,picH);\n\  
  }//for i\n\   
  for(i=-5; i<=5; i++){\n\
    y=remap(i*100*grScale,Amin,Amax,Ymin,Ymax);\n\
    gr.strokeRect(0,y,picW,0);\n\
  }//for i\n\   
}//Grid\n\ 
function remap(x,xMin,xMax,yMin,yMax){\n\
  return(yMin+(yMax-yMin)*(x-xMin)/(xMax-xMin));\n\
}//remap\n\
function Graph(){\n\
  x0=remap(0,Amin,Amax,Xmin,Xmax); y0=remap(0,Amin,Amax,Ymin,Ymax);\n\
  x=remap(Acos*grScale,Amin,Amax,Xmin,Xmax);\n\ 
  y=remap(Asin*grScale,Amin,Amax,Ymin,Ymax);\n\ 
  gr.lineWidth=2; gr.strokeStyle='#ff0000';\n\
  gr.beginPath(); gr.moveTo(x0,y0); gr.lineTo(x0,y); gr.stroke();\n\
  gr.beginPath(); gr.moveTo(x0,y0); gr.lineTo(x,y0); gr.stroke();\n\
  gr.lineWidth=3; gr.strokeStyle='#000000';\n\
  gr.beginPath(); gr.moveTo(x0,y0); gr.lineTo(x,y); gr.stroke();\n\
  y=remap(dB,dBmin,dBmax,Ymin,Ymax);\n\ 
  gr.strokeRect(picW+5,picH,5,y-Ymin);\n\
}//Graph\n\
function newScale(x){grScale=x; Draw();}\n\
//------------------------------------------------------------------------------\n\
");
}//genHTML1
void genHTML2(){
  HTMLstring=F("\n\
function decodeRxS(){\n\
  if ((RxS.length>10)&&(RxS[0]!='#')){\n\
   //_inText.value=RxS;\n\
    RxV=RxS.split('\\t');\n\
    fwork=eval(RxV[0]); Asin=eval(RxV[1]); Acos=eval(RxV[2]); Aavr=eval(RxV[3]);\n\
    A0=Math.sqrt(Asin*Asin+Acos*Acos); Phi=Math.atan2(Acos,Asin)*180/Math.PI;\n\
    _fwork.value=fwork; _Asin.value=Asin; _Acos.value=Acos; _Aavr.value=Aavr;\n\ 
    _A0.value=A0.toFixed(2); _Phi.value=Phi.toFixed(2);\n\          
    dB=Math.log10(A0)*20; _dB.value=dB.toFixed(2);\n\ 
  }//if\n\  
}//decodeRxS\n\
function sendCTL(s){ ws.send('#'+s); }\n\
function LinScaleF(Fmin,Fmax,r){\n\
  return (Fmin+(Fmax-Fmin)*r/100);\n\
}//LinScaleF\n\
function LogScaleF(Fmin,Fmax,r){\n\
  LnFmin=Math.log(Fmin); LnFmax=Math.log(Fmax);\n\
  Lnf=(LnFmin+(LnFmax-LnFmin)*r/100);\n\
  return (Math.exp(Lnf));\n\ 
}//LogScaleF\n\
function LinScaleR(Fmin,Fmax,f){\n\
  return ((f-Fmin)/(Fmax-Fmin)*100);\n\
}//LinScaleR\n\
function LogScaleR(Fmin,Fmax,f){\n\
  LnFmin=Math.log(Fmin); LnFmax=Math.log(Fmax);\n\
  Lnf=Math.log(f);\n\
  return ((Lnf-LnFmin)/(LnFmax-LnFmin)*100);\n\
}//LogScaleR\n\
function newData(x){\n\
  var Fmin=eval(_fmin.value); var Fmax=eval(_fmax.value);\n\
  if (_fLog.checked) var f=LogScaleF(Fmin,Fmax,x);\n\
  else var f=LinScaleF(Fmin,Fmax,x);\n\
  f=f.toFixed(2);\n\
  sendCTL('fl'+f);\n\
  _fcur.value=f;\n\
}//newData\n\
function newDataT(x){\n\
  var Fmin=eval(_fmin.value); var Fmax=eval(_fmax.value);\n\
  if (_fLog.checked) var r=LogScaleR(Fmin,Fmax,x);\n\
  else var r=LinScaleR(Fmin,Fmax,x);\n\
  _frng.value=r;\n\
  sendCTL('fl'+x);\n\
}//newDataT\n\   
function initCTL(){\n\
  newData(_frng.value);\n\
  RxS='';\n\ 
  sendCTL('fn1'); newData(50);\n\
}//initCTL\n\
function initCTLdelay(){ setTimeout(initCTL,1000);}\n\  
</script></head>\n\
<body onload=initCTLdelay()>\n\
<!--<input type=text id=_inText style='width:100%; font-size:20px' value=''>-->\n\
<table width=100%>\n\
<tr><td rowspan=9><canvas id=myPic></canvas></td>\n\
<td>f=<input type=text id=_fwork value=''>; &nbsp; Aa=<input type=text id=_Aavr value=''>;</td></tr>\n\
<tr><td>As=<input type=text id=_Asin value=''>; &nbsp; Ac=<input type=text id=_Acos value=''>;</td></tr>\n\
<tr><td>A0=<input type=text id=_A0 value=''>; &nbsp; Phi=<input type=text id=_Phi value=''>;</td></tr>\n\
<tr><td>dB=<input type=text id=_dB value=''>;</td></tr>\n\
<tr><td><hr></td></tr>\n\
<tr><td>Scale=<input type=text id=_scale value='1' onchange=newScale(this.value)></td></tr>\n\
<tr><td><hr></td></tr>\n\
<tr><td>fmin=<input type=text id=_fmin value=10>; fmax=<input type=text id=_fmax value=3000>;\n\
<input id=_fLog type=checkbox checked>Log</td></tr>\n\ 
<tr><td>fnew=<input type=text id=_fcur value='' onchange=newDataT(this.value)></td></tr>\n\
</table>\n\
<input type=range id=_frng value=50 onInput=newData(this.value)>\n\
<script>\n\
winH=window.innerHeight; winW=window.innerWidth;\n\
picH=winH-100; picW=picH; picBorder=12;\n\
myPic.height=picH; myPic.width=picW+picBorder;\n\
gr=myPic.getContext('2d');\n\ 
Ymin=picH; Ymax=0; Xmin=0; Xmax=picW;\n\
grBusy=false;\n\
Draw();\n\
</script>\n\
</body>\n</html>");
}//genHTML2
