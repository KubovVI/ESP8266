void decodeCTL(String s){
  Serial.println(s);
}//decodeCTL

void consHTML(){
  HTMLstring=F(""
  "<html><head><style>\n"
  "body,table,input,textarea {font-size:20px}\n"
  "input[type=checkbox]{width:20px; height:20px}\n" 
  "</style><script>\n"
  "RxGo=true;\n"
  "ws=new WebSocket('ws://192.168.4.1:81/');\n"
  "ws.onmessage=function(msg){\n"
    "ws.binaryType='arraybuffer';\n"
    "if (msg.data instanceof ArrayBuffer){\n"
      "Buffer=new Uint8Array(msg.data);\n"
      "if (RxGo){\n"
        "RxS.value=RxS.value+String.fromCharCode.apply(null,Buffer);\n" 
        "if (RxScr.checked) RxS.scrollTop=RxS.scrollHeight;\n"
      "}//if RxGo\n"  
    "}//if msg.data\n" 
  "}//onmessage \n"
  "function sendCTL(){\n"
    "ws.send('#'+TxS.value);\n"
  "}//sendCTL\n"
  "function initCTL(){\n"
    "RxS.value=''; TxS.value='';\n"
    "RxGo=true;\n"
  "}//initCTL\n"
  "function clearRxS(){RxS.value='';}\n"
  "function changeRx(){\n"
    "RxGo=!RxGo;\n"
    "if (RxGo) RxRun.value='Stop'; else RxRun.value='Run';\n"
  "}//changeRx\n"
  "</script></head>\n"
  "<body onload='initCTL()'>\n"
  "<table align=center border=0>\n"
  "<tr><td>Tx: <input type=text id=TxS size=10 style='text-align:left' value=''>\n"
  " &nbsp <input type=button value='Send' onClick='sendCTL()'>\n"
  " &nbsp <input type=checkbox id=RxScr checked> Scroll\n"
  " &nbsp <input type=button id=RxRun value='Stop' onClick='changeRx()'>\n"
  " &nbsp <input type=button value='Clear' onClick='clearRxS()'>\n"
  "</td></tr>\n" 
  "<tr><td>Rx: <textarea id=RxS cols=50 rows=25 value=''></td></tr>\n"
  "</table>\n"
  "</body></html>");
}//consHTML

void processingCons(){
  if (sSerial.available()){
    TxString=sSerial.readStringUntil('\n');
    wsBroadcast();
    Serial.println(TxString);
  }//if sSerial.available
  if (RxString.length()){
    sSerial.println(RxString);
    Serial.println(RxString);
    RxString="";
  }//if RxString
}//processingCons  
